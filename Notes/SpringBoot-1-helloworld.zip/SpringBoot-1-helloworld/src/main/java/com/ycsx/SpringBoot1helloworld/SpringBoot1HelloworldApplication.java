package com.ycsx.SpringBoot1helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot1HelloworldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot1HelloworldApplication.class, args);
	}

}
