package com.ycsx.SpringBoot1helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot1HelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
